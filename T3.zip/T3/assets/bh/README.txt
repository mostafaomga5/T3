ضع هنا: bg.webp, char.webp, s1.webp ... s6.webp
